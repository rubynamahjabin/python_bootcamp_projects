from flask import Flask

app = Flask(__name__) #Creates a Flask application object

@app.route('/') #root route
def hello_world():
    return 'Hello, World!'

@app.route("/bye") #another route
def say_bye():
    return "Bye"

if __name__ == "__main__": #Ensures the app only runs when you execute the script directly, not when it's imported
    app.run() #Starts the development server