import time

#This is a decorator function that measures how long another function takes to run
def speed_calc_decorator(func):
    #Wrapper function will replace the original function
    def wrapper(*args, **kwargs):
        start_time = time.time() #Records the start time
                                 #time.time() returns the current time in seconds since the Unix Epoch (January 1, 1970, 00:00:00 UTC) (often called a timestamp)
        result = func(*args, **kwargs) #Calls the original function
        end_time = time.time() #Records the end time
        print(f"{func.__name__} run speed: {end_time - start_time:}s") #Prints the execution time of the function
        return result
    return wrapper

#Apply the decorator to measure execution time of this function
@speed_calc_decorator
def fast_function():
    for i in range(1000000): #This loop runs 1 million times
        i * i

#Apply the decorator to measure execution time of this function
@speed_calc_decorator
def slow_function():
    for i in range(10000000): #This loop runs 10 million times
        i * i

fast_function()
slow_function()